# CMCS Prototype (ASP.NET Core MVC, .NET 8)

This repository contains the **Part 1 UI prototype** for the Contract Monthly Claim System (CMCS) as per PROG6212 POE.

> Note: This is a *front-end prototype*. There is **no database**. State is kept in-memory for demo purposes only.

## How to run

1. Install .NET 8 SDK: https://dotnet.microsoft.com/en-us/download/dotnet/8.0
2. Open a terminal in this folder.
3. Run:
   ```bash
   dotnet restore
   dotnet build
   dotnet run
   ```
4. Browse to `http://localhost:5000` or the URL shown in the console.

## Screens (UI only)
- Home (overview)
- Claims/Submit — Draft a claim (auto-calculates total on the page)
- Claims/Upload — Upload supporting document (prototype message only)
- Claims/Track — View list of drafted claims (in-memory)
- Approvals — Coordinator/Manager view to approve/reject (prototype only)

## Next (Part 2)
- Add EF Core + DB schema for Lecturer, Claim, Document, Approval
- Real file storage with constraints (.pdf/.docx/.xlsx)
- Role-based auth (Lecturer, Coordinator, Manager)
- Unit tests + error handling
