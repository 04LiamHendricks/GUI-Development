using Microsoft.AspNetCore.Mvc;
using CMCS.Models;

namespace CMCS.Controllers;

public class ClaimsController : Controller
{
    // In-memory demo store (prototype only; not persisted)
    private static readonly List<Claim> _claims = new();

    [HttpGet]
    public IActionResult Submit() => View(new Claim());

    [HttpPost]
    public IActionResult Submit(Claim model)
    {
        // Prototype-only: no DB, minimal validation
        if (!ModelState.IsValid) return View(model);

        model.ClaimID = _claims.Count + 1;
        model.Status = ClaimStatus.Pending;
        _claims.Add(model);
        TempData["Message"] = "Claim drafted (prototype). In Part 2 this will save to DB.";
        return RedirectToAction("Track");
    }

    [HttpGet]
    public IActionResult Upload() => View();

    [HttpPost]
    public IActionResult Upload(IFormFile? file)
    {
        if (file == null || file.Length == 0)
        {
            TempData["Error"] = "Please select a .pdf, .docx or .xlsx file.";
            return View();
        }
        TempData["Message"] = $"Uploaded {file.FileName} (prototype only).";
        return RedirectToAction("Track");
    }

    public IActionResult Track() => View(_claims);
}
