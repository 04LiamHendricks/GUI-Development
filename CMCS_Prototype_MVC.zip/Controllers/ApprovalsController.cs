using Microsoft.AspNetCore.Mvc;
using CMCS.Models;

namespace CMCS.Controllers;

public class ApprovalsController : Controller
{
    // Access the in-memory claims from ClaimsController for demo purposes
    private static readonly List<Claim> _claims = typeof(ClaimsController)
        .GetField("_claims", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static)?
        .GetValue(null) as List<Claim> ?? new();

    public IActionResult Index() => View(_claims);

    [HttpPost]
    public IActionResult Decide(int id, string decision)
    {
        var claim = _claims.FirstOrDefault(c => c.ClaimID == id);
        if (claim != null)
        {
            claim.Status = decision?.ToLower() == "approve" ? ClaimStatus.Approved : ClaimStatus.Rejected;
            TempData["Message"] = $"Claim {id} set to {claim.Status} (prototype).";
        }
        return RedirectToAction("Index");
    }
}
