using System.ComponentModel.DataAnnotations;

namespace CMCS.Models;

public class Document
{
    public int DocumentID { get; set; }
    public int ClaimID { get; set; }

    [Required, StringLength(260)]
    public string FileName { get; set; } = string.Empty;

    public DateTime UploadDate { get; set; } = DateTime.UtcNow;
}
