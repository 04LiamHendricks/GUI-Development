using System.ComponentModel.DataAnnotations;

namespace CMCS.Models;

public enum ClaimStatus { Draft, Pending, Approved, Rejected }

public class Claim
{
    public int ClaimID { get; set; }

    [Required]
    public int LecturerID { get; set; }

    [Range(0, 400)]
    public decimal HoursWorked { get; set; }

    [Range(0, 2000)]
    public decimal HourlyRate { get; set; }

    [DisplayFormat(DataFormatString = "{0:C}")]
    public decimal TotalAmount => HoursWorked * HourlyRate;

    public ClaimStatus Status { get; set; } = ClaimStatus.Draft;

    [StringLength(500)]
    public string? Notes { get; set; }
}
