using System.ComponentModel.DataAnnotations;

namespace CMCS.Models;

public class Approval
{
    public int ApprovalID { get; set; }
    public int ClaimID { get; set; }

    [Required, StringLength(100)]
    public string ApprovedBy { get; set; } = string.Empty;

    [Required, StringLength(50)]
    public string Role { get; set; } = "Coordinator";

    public DateTime DateApproved { get; set; } = DateTime.UtcNow;

    [Required, StringLength(20)]
    public string Status { get; set; } = "Pending";
}
