using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CMCS.Models;
using Microsoft.AspNetCore.Authorization;

namespace CMCS.Controllers
{
    [Authorize(Roles = "Lecturer")]
    public class ClaimsController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IWebHostEnvironment _environment;

        public ClaimsController(ApplicationDbContext context, IWebHostEnvironment environment)
        {
            _context = context;
            _environment = environment;
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Claim claim, IFormFile? supportingDocument)
        {
            if (ModelState.IsValid)
            {
                // Get the current lecturer
                var lecturer = await _context.Lecturers
                    .FirstOrDefaultAsync(l => l.Email == User.Identity.Name);

                if (lecturer == null)
                {
                    ModelState.AddModelError("", "Lecturer profile not found.");
                    return View(claim);
                }

                // Auto-calculate total amount
                claim.TotalAmount = (decimal)claim.HoursWorked * claim.HourlyRate;
                claim.Status = "Pending";
                claim.LecturerId = lecturer.Id;
                claim.SubmissionDate = DateTime.Now;

                _context.Add(claim);
                await _context.SaveChangesAsync();

                // Handle file upload
                if (supportingDocument != null && supportingDocument.Length > 0)
                {
                    // Validate file type and size
                    var allowedExtensions = new[] { ".pdf", ".docx", ".xlsx" };
                    var fileExtension = Path.GetExtension(supportingDocument.FileName).ToLower();
                    
                    if (!allowedExtensions.Contains(fileExtension))
                    {
                        ModelState.AddModelError("", "Invalid file type. Only PDF, DOCX, and XLSX files are allowed.");
                        return View(claim);
                    }

                    if (supportingDocument.Length > 5 * 1024 * 1024) // 5MB limit
                    {
                        ModelState.AddModelError("", "File size too large. Maximum size is 5MB.");
                        return View(claim);
                    }

                    var uploadsFolder = Path.Combine(_environment.WebRootPath, "uploads");
                    if (!Directory.Exists(uploadsFolder))
                    {
                        Directory.CreateDirectory(uploadsFolder);
                    }

                    var uniqueFileName = Guid.NewGuid().ToString() + "_" + supportingDocument.FileName;
                    var filePath = Path.Combine(uploadsFolder, uniqueFileName);

                    using (var fileStream = new FileStream(filePath, FileMode.Create))
                    {
                        await supportingDocument.CopyToAsync(fileStream);
                    }

                    var document = new SupportingDocument
                    {
                        ClaimId = claim.Id,
                        FileName = supportingDocument.FileName,
                        FilePath = uniqueFileName
                    };
                    _context.SupportingDocuments.Add(document);
                    await _context.SaveChangesAsync();
                }

                TempData["SuccessMessage"] = "Claim submitted successfully!";
                return RedirectToAction("MyClaims", "Home");
            }
            return View(claim);
        }
    }
}