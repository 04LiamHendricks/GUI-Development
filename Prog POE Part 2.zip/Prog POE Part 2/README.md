# CMCS - Contract Monthly Claim System (Part 2)

This repository contains the **fully functional Part 2 implementation** for the Contract Monthly Claim System (CMCS) as per PROG6212 POE requirements.

## Features Implemented

✅ **Lecturer Claim Submission**: Simple form with auto-calculation of total amount  
✅ **Coordinator/Manager Approval**: Separate view to verify and approve/reject claims  
✅ **Document Upload**: Secure file upload with validation (PDF, DOCX, XLSX, max 5MB)  
✅ **Claim Status Tracking**: Real-time status updates (Pending → Approved/Rejected)  
✅ **Role-based Authentication**: Lecturer, Coordinator, and Manager roles  
✅ **Error Handling**: Comprehensive validation and error messages  
✅ **Database Integration**: Entity Framework Core with SQL Server/LocalDB  

## How to Run

1. **Install .NET 8 SDK**: https://dotnet.microsoft.com/en-us/download/dotnet/8.0
2. **Open terminal** in this folder
3. **Run commands**:
   ```bash
   dotnet restore
   dotnet build
   dotnet run