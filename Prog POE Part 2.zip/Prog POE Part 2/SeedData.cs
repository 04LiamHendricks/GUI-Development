using Microsoft.AspNetCore.Identity;

namespace CMCS.Models
{
    public static class SeedData
    {
        public static async Task Initialize(RoleManager<IdentityRole> roleManager, 
                                          UserManager<IdentityUser> userManager,
                                          ApplicationDbContext context)
        {
            // Create roles
            string[] roleNames = { "Lecturer", "Coordinator", "Manager" };
            foreach (var roleName in roleNames)
            {
                if (!await roleManager.RoleExistsAsync(roleName))
                {
                    await roleManager.CreateAsync(new IdentityRole(roleName));
                }
            }

            // Create default users for each role
            var lecturerUser = new IdentityUser { UserName = "lecturer@cmcs.com", Email = "lecturer@cmcs.com" };
            var coordinatorUser = new IdentityUser { UserName = "coordinator@cmcs.com", Email = "coordinator@cmcs.com" };
            var managerUser = new IdentityUser { UserName = "manager@cmcs.com", Email = "manager@cmcs.com" };

            if (await userManager.FindByEmailAsync("lecturer@cmcs.com") == null)
            {
                await userManager.CreateAsync(lecturerUser, "password");
                await userManager.AddToRoleAsync(lecturerUser, "Lecturer");
                
                // Create lecturer profile
                var lecturer = new Lecturer
                {
                    UserId = lecturerUser.Id,
                    Name = "John Lecturer",
                    Email = "lecturer@cmcs.com"
                };
                context.Lecturers.Add(lecturer);
            }

            if (await userManager.FindByEmailAsync("coordinator@cmcs.com") == null)
            {
                await userManager.CreateAsync(coordinatorUser, "password");
                await userManager.AddToRoleAsync(coordinatorUser, "Coordinator");
            }

            if (await userManager.FindByEmailAsync("manager@cmcs.com") == null)
            {
                await userManager.CreateAsync(managerUser, "password");
                await userManager.AddToRoleAsync(managerUser, "Manager");
            }

            await context.SaveChangesAsync();
        }
    }
}