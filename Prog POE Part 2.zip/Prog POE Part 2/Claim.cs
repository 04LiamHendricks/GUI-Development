using System.ComponentModel.DataAnnotations;

namespace CMCS.Models
{
    public class Claim
    {
        public int Id { get; set; }
        
        [Required]
        public int LecturerId { get; set; }
        
        [Required]
        [Range(0.1, 1000, ErrorMessage = "Hours worked must be between 0.1 and 1000")]
        public double HoursWorked { get; set; }
        
        [Required]
        [Range(1, 1000, ErrorMessage = "Hourly rate must be between 1 and 1000")]
        public decimal HourlyRate { get; set; }
        
        public decimal TotalAmount { get; set; }
        public string Status { get; set; } = "Pending";
        public DateTime SubmissionDate { get; set; } = DateTime.Now;
        
        [StringLength(500)]
        public string? Notes { get; set; }

        public Lecturer? Lecturer { get; set; }
        public ICollection<SupportingDocument> SupportingDocuments { get; set; } = new List<SupportingDocument>();
    }
}