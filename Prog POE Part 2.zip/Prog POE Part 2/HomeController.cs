using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CMCS.Models;
using Microsoft.AspNetCore.Authorization;

namespace CMCS.Controllers
{
    public class HomeController : Controller
    {
        private readonly ApplicationDbContext _context;

        public HomeController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        [Authorize(Roles = "Lecturer")]
        public async Task<IActionResult> MyClaims()
        {
            var lecturer = await _context.Lecturers
                .FirstOrDefaultAsync(l => l.Email == User.Identity.Name);

            if (lecturer == null) return NotFound();

            var claims = await _context.Claims
                .Where(c => c.LecturerId == lecturer.Id)
                .OrderByDescending(c => c.SubmissionDate)
                .ToListAsync();

            return View(claims);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View();
        }
    }
}